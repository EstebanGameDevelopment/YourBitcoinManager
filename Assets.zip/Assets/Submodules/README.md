-----------------------
-----------------------
YOUR BITCOIN CONTROLLER
-----------------------
-----------------------

Thanks to this plugin you will be able to include Bitcoin cryptocurreny and Blockchain signning authentication
in your games and applications.

TUTORIAL
--------

 1. SET UP THE RUNTIME:

	First of all, we make sure that the Scripting Runtime Version: ".NET 4.x Equivalent" in order for the NBitcoin DLL to work.
 
 2. INSTALLATION OF NBitcoin DLL:
 
	On Visual Studio open the NuGet console and run the command line: "Install-Package NBitcoin -Version 4.1.1.19"
	
	After installing the DLL you will be able to run the code without problems.

  3. Run the scene BasicManager.unity and you will be able to perform operations with Bitcoins.
  
	 Follow the instructions on the video tutorial:
	 
		https://youtu.be/5Nj8FKymhjc
		
  4. Run the scene CreateKeys.unity to create new wallets
  
	 Follow the instructions on the last part of the video tutorial (time 2:32):
	 
		https://youtu.be/5Nj8FKymhjc?t=2m32s
		
  5. Run the scenes SignTextData.unity and SignImageData.unity to sign data and document using your keys
  
	 Follow the instructions on the video tutorial:
	 
		https://youtu.be/5Nj8FKymhjc?t=3m16s
		
