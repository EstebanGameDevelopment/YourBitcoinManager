using System;
using UnityEngine;
using System.Xml;
using System.Collections;
using System.Collections.Generic;

namespace YourCommonTools
{

    /******************************************
	 * 
	 * ClassFinder
	 * 
	 * @author Esteban Gallardo
	 */
    public class ClassFinder : MonoBehaviour
	{
        public string Name;
	}
}