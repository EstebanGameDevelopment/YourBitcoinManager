YOUR BITCOIN MANAGER
----------------
Thanks for downloading this package.

Thanks to this plugin you will be able to include Bitcoin cryptocurreny and Blockchain signning authentication
in your games and applications.

TUTORIAL
--------

 1. SET UP THE RUNTIME:

	First of all, we make sure that the Scripting Runtime Version: ".NET 4.x Equivalent" in order for the NBitcoin DLL to work.
 
 2. INSTALLATION OF NBitcoin DLL:
 
	On Visual Studio open the NuGet console and run the command line: "Install-Package NBitcoin"
	
	After installing the DLL you will be able to run the code without problems.

  3. You can find the basic installation video tutorial:
  
		https://youtu.be/qqK3heJMsNk
	
  4. Run the scene YourBitcoinManager.unity and you will be able to perform operations with Bitcoins.
  
	 Follow the instructions on the video tutorial playlist:
	 
		https://www.youtube.com/playlist?list=PLPtjK_bez3T6TksPR5b7IsVbNmdLHmz8_
		
