﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using YourBitcoinController;
using YourCommonTools;

namespace YourBitcoinManager
{
	/******************************************
	 * 
	 * SlotAddressView
	 * 
	 * Slot that will be used to display an address with its label
	 * 
	 * @author Esteban Gallardo
	 */
	public class SlotAddressView : Button, ISlotView
	{
		// ----------------------------------------------
		// EVENTS
		// ----------------------------------------------	
		public const string EVENT_SLOT_ADDRESS_SELECTED = "EVENT_SLOT_ADDRESS_SELECTED";

		// ----------------------------------------------
		// PRIVATE MEMBERS
		// ----------------------------------------------	
		private Transform m_container;
		private string m_address;
		private string m_label;

		// -------------------------------------------
		/* 
		 * Constructor
		 */
		public void Initialize(params object[] _list)
		{
			ItemMultiObjectEntry item = (ItemMultiObjectEntry)_list[0];

			m_container = this.gameObject.transform;
			
			m_address = (string)item.Objects[0];
			m_label = (string)item.Objects[1];

			m_container.Find("Label").GetComponent<Text>().text = m_label;
			m_container.Find("Address").GetComponent<Text>().text = m_address;
		}


		// -------------------------------------------
		/* 
		 * Destroy
		 */
		public bool Destroy()
		{
			GameObject.Destroy(this.gameObject);
			return true;
		}

		// -------------------------------------------
		/* 
		 * OnPointerClick
		 */
		public override void OnPointerClick(PointerEventData eventData)
		{
			base.OnPointerClick(eventData);
			UIEventController.Instance.DispatchUIEvent(EVENT_SLOT_ADDRESS_SELECTED, m_address);
		}

        // -------------------------------------------
        /* 
		 * GetOnClick
		 */
        public ButtonClickedEvent GetOnClick()
        {
            return this.onClick;
        }

        // -------------------------------------------
        /* 
		 * RunOnClick
		 */
        public bool RunOnClick()
        {
            UIEventController.Instance.DispatchUIEvent(EVENT_SLOT_ADDRESS_SELECTED, m_address);
            return true;
        }
    }
}